How to run Project
1. Download and Unzip the file on your local system copy myproject .
2. Put myproject folder inside root directory (for xampp xampp/htdocs, for wamp wamp/www, for lamp var/www/html)

Database Configuration
Open phpmyadmin
Create Database carrental
Import database carrental.sql (available SQL File Folder inside zip package)

For User
Open Your browser put inside browser “http://localhost/myproject”
Login Details for user:
Username : test@gmail.com
Password: Test@12345
 	or
Username : sharifali0926@gmail.com
Password: 12345
	or 
Username : p200119@pwr.nu.edu.pk
Password: taha

For Admin Panel
Open Your browser put inside browser “http://localhost/myproject/admin”
Login Details for admin :
Username: admin
Password: Test@12345
